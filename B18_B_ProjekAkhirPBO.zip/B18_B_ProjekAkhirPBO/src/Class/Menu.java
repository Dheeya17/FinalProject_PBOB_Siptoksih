package Class;

public abstract class Menu {
        final public String nama;
        public Menu(String Nama){
                this.nama = Nama;
        }

        public void viewMenu(){}
}
