package Class;

public interface Greetings {
    void greetUser();
}
